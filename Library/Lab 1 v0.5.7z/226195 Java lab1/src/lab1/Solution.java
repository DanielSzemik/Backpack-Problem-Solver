package lab1;

import java.util.List;

/**
 * klasa przechowuje rozwiazanie problemu
 * @author pas109
 *
 */
public class Solution {
	
	/**
	 * rozwiazanie przechowywana jest w tablicy integer�w, jedynka 
	 * oznacza i� przedmiot jest zawarty w rozwi�zaniu
	 */
	int[] rozwiazanie;
	
	/**
	 * 
	 * @param rozwiazanie - rozwiazanie problemu
	 */
	public Solution(int[] rozwiazanie)
	{
		this.rozwiazanie = rozwiazanie;
	}
	
	/**
	 * metoda wyswietla wynik, printuje cechy przedmiot�w w rozwi�zaniu oraz
	 * sumy ich wag i wartosci
	 * 
	 * @param lista lista przedmiotow typu Item
	 */
	public void wyswwynik(List<Item> lista) {
		int n = 1;
		int totalweight = 0;
		float totalvalue = 0;
		for(int i=0; i<rozwiazanie.length;i++)
		{
			if (rozwiazanie[i]==1)
			{
				System.out.println("Przedmiot " + n + ": Waga - " + lista.get(i).getweight() + " Wartosc - " + lista.get(i).getvalue());
				totalweight += lista.get(i).getweight();
				totalvalue += lista.get(i).getvalue();
				n++;
			}
		}
		System.out.println("Suma wag: " + totalweight + " Suma wartosci: " + totalvalue);
	}
	
}
