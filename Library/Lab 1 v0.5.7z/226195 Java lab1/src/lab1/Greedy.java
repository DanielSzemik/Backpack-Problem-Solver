package lab1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Klasa roziwazuje problem plecakowy algorytmem przegladu zupelnego,
 * nalezy podac liste przedmiotow oraz maksymalna pojemnosc plecaka
 */
public class Greedy {
	int bestrozw[];
	/**

	 * @param lista - Lista przedmiotow typu klasy Item
	 * @param maxweight - maksymalna waga jako moze przechowywac plecak
	 */
	public Greedy(List<Item> lista,int maxweight) {
		int totalweight = 0;
		float totalvalue = 0;
		List<Item> posortowanalista = new ArrayList<Item>(lista);
		Collections.sort(posortowanalista, new ItemGreedyComparator());
		int bestrozw[] = new int[posortowanalista.size()];
		
		for(int i=0;i<posortowanalista.size()-1;i++)
		{
			if (totalweight + posortowanalista.get(i).getweight() <= maxweight)
			{
				totalweight += posortowanalista.get(i).getweight();
				totalvalue += posortowanalista.get(i).getvalue();
				bestrozw[posortowanalista.get(i).getnr()-1]=1;
			}
		}
		this.bestrozw = bestrozw;
	}
	/**
	 * Getter zwracajacy wynik algorytmu przechowywanego w tablicy bestrozw
	 * @return najlepsze znalezione rozwi�zanie algorytmu
	 */
	public int[] getrozw() {
		return bestrozw;
	}
	/**
	 * funkcja zwraca string z opisem algorytmu
	 * @return opis algorytmu
	 */
	public String opis()
	{
		return "Algorytm zachlanny - Priorytetr wyboru to stosunek wartosci od masy";
	}

}

/**
 * Klasa kt�ra por�wnuje dwa przedmioty aby znalezc ktory ma lepszy stosunek 
 * wartosci do wagi
 * @param item1 pierwszy przedmiot
 * @param item2 drugi przedmiot
 * @return Zwraca 0 jezeli pierwszy przedmiot jest lepszy lub rowny, 1 jezeli drugi
 */
class ItemGreedyComparator implements Comparator<Item>{
	public int compare(Item item1, Item item2) {
		return (int) (item1.getvalue()/item1.getweight() - item1.getvalue()/item1.getweight());
	}
}
